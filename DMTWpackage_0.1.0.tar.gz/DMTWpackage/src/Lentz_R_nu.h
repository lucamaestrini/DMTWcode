#ifndef LENTZ_R_NU
   #define LENTZ_R_NU
   double Lentz_R_nu(const double x, const double nu);
#endif
