#ifndef LENTZ_Q
#define LENTZ_Q
  double Lentz_Q(const double x);
#endif
